#include <bits/stdc++.h>

using namespace std;

using ll = long long;

int main() {
  int t;
  cin >> t;
  while (t--) {
    ll a,b,c;
    cin >> a >> b >> c;
    auto check = [&]() {
      bool ok = false;
      if (a % b == 0 && a/b == c) {
        ok = true;
      }
      if (a + b == c) {
        ok = true;
      }
      if (a * b == c) {
        ok = true;
      }
      if (a - b == c) {
        ok = true;
      }
      return ok;
    };
    if (check()) {
      cout << "Possible" << "\n";
      continue;
    }
    swap(a,b);
    if (check()) {
      cout << "Possible" << "\n";
      continue;
    }
    cout << "Impossible" << "\n";
  }
}
