#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 1e6 + 10;

bool is_prime[N+1];
int spf[N+1];
vector<int> primes;
void sieve() {
  fill(begin(is_prime) + 2, end(is_prime), true);
  for (int i = 2; i <= N; i++) {
    if (is_prime[i]) {
      primes.push_back(i);
      spf[i] = i;
    }
    for (int j = 0; j < primes.size() && (ll)i * primes[j] <= N && primes[j] <= spf[i]; j ++) {
      is_prime[i*primes[j]] = false;
      spf[i*primes[j]] = primes[j];
    }
  }
}

int binexp(int p, int k) {
  int res = 1;
  while (k--) {
    res *= p;
  }
  return res;
}

int main() {
  sieve();
  int n;
  cin >> n;
  vector<int> A(n);
  map<int,set<int>> factors;
  map<int,int> dups;
  for (int i=0;i<n;i++){
    cin >> A[i];
    int a = A[i];
    while (a != 1) {
      int p = spf[a];
      int cnt = 0;
      while (a % p == 0) {
        cnt ++;
        a /= p;
      }
      if (factors[p].empty() || *--factors[p].end() < cnt) {
        dups[p] = 1;
      } else if (*--factors[p].end() == cnt) {
        dups[p] ++;
      }
      factors[p].insert(cnt);
    }
  }
  pair<ll,int> ans = {1e18,0};
  for (int i=0;i<n;i++){
    ll div = 1;
    int a = A[i];
    while (a != 1) {
      int p = spf[a];
      int cnt = 0;
      while (a % p == 0) {
        cnt ++;
        a /= p;
      }
      if (*--factors[p].end() == cnt && dups[p] == 1) {
        if (factors[p].size() == 1) {
          div *= binexp(p, cnt);
        } else {
          auto it = factors[p].end();
          --it;
          --it;
          div *= binexp(p, cnt-*it);
        }
      }
    }
    ans = min(ans, {div, A[i]});
  }
  cout << ans.second << "\n";
}
