#include <bits/stdc++.h>

using namespace std;
using ll = long long;

struct bipariate_match {
  int n,m;
  vector<int> mt;
  vector<vector<int>> adj;
  bipariate_match(int n, int m) : n(n), m(m), mt(m, -1), adj(n) {}
  void add(int u, int v) {
    adj[u].push_back(v);
  }
  void run() {
    vector<bool> vis;
    auto dfs = [&](auto self, int u) -> bool {
      if (vis[u]) return false;
      vis[u] = true;
      for (int v : adj[u]) {
        if (mt[v] == -1 || self(self, mt[v])) {
          mt[v] = u;
          return true;
        }
      }
      return false;
    };

    // arbitrary matching heuristics
    vector<bool> used(n);
    for (int i=0;i<n;i++){
      for (int v : adj[i]) {
        if (mt[v] == -1) {
          mt[v] = i;
          used[i] = true;
          break;
        }
      }
    }

    for (int i=0;i<n;i++) {
      if (used[i]) continue; // add mt[i] != -1 check when abitrary
      vis.assign(n, false);
      dfs(dfs, i);
    }
  }
};

double calc_dist(pair<int,int> a, pair<int,int> b) {
  return sqrt(pow(a.first - b.first, 2) + pow(a.second - b.second, 2));
}

int main() {
  int n, b, r;
  cin >> n >> b >> r;

  vector<vector<double>> dist(b, vector<double>(r));

  auto f = [&](double k) -> bool {
    bipariate_match bm(b, r);
    for (int i=0;i<b;i++) {
      for (int j=0;j<r;j++) {
        if (dist[i][j] < k) {
          bm.add(i,j);
        }
      }
    }
    bm.run();
    int done = 0;
    for (int v : bm.mt) {
      if (v != -1) {
        done++;
      }
    }
    return r+b-done >= n;
  };

  vector<pair<int,int>> blues(b), reds(r);
  for (int i=0;i<b;i++) {
    cin >> blues[i].first >> blues[i].second;
  }
  for (int i=0;i<r;i++) {
    cin >> reds[i].first >> reds[i].second;
  }
  for (int i=0;i<b;i++) {
    for (int j=0;j<r;j++) {
      dist[i][j] = calc_dist(blues[i], reds[j]);
    }
  }
  
  double ok = 0.0, ng = 1e9;
  for (int k=0;k<100;k++) {
    double mid = (ok+ng) / 2.0;
    if (f(mid)) {
      ok = mid;
    } else {
      ng = mid;
    }
  }
  cout << setprecision(20) << fixed << ok << "\n";
}
