#include <bits/stdc++.h>

using namespace std;
using ll = long long;

vector<int> A;

struct union_find {
  int n;
  vector<int> p;
  vector<int> sz;
  vector<int> sz2;
  vector<ll> sum;
  union_find(int n) : n(n), p(n), sz(n, 1), sum(begin(A),end(A)), sz2(n,1) {
    iota(begin(p),end(p), 0);
  }
  
  int leader(int x) {
    if (p[x] == x) {
      return x;
    }
    return p[x] = leader(p[x]);
  }

  void unite(int x, int y) {
    int l = leader(x), s = leader(y);
    if (l == s) { 
      return;
    }
    if (sz[s] > sz[l]) swap(l,s);
    p[s] = l;
    sz[l] += sz[s];
    sz2[l] += sz2[s];
    sum[l] += sum[s];
  }

  int add(int o, int a, int pp) {
    int la = leader(a), lp = leader(pp);
    if (la == lp) {
      return -1;
    }
    sz2[la] --;
    sum[la] -= A[o];
    sz2[lp] ++;
    sum[lp] += A[o];
    sz.push_back(1);
    sz2.push_back(0);
    p.push_back(lp);
    sum.push_back(0);
    return sz.size() - 1;
  }
};

void solve(int n, int q) {
  vector<int> cur(n);
  iota(begin(cur),end(cur), 0);
  A = vector<int>(n, 0);
  iota(begin(A),end(A), 1);
  union_find uf(n);
  while(q--) {
    int t;
    cin >> t;
    if (t == 1) {
      int p,q;
      cin >> p >> q;
      --p,--q;
      uf.unite(cur[p], cur[q]);
    }
    if (t == 2) {
      int p,q;
      cin >> p >> q;
      --p,--q;
      int res = uf.add(p, cur[p], cur[q]);
      if (res != -1) {
        cur[p] = res;
      }
    }
    if (t == 3) {
      int p;
      cin >> p;
      --p;
      cout << uf.sz2[uf.leader(cur[p])] << " " << uf.sum[uf.leader(cur[p])] << "\n";
    }
  }
}

int main() {
  int n,q;
  while (cin >> n >> q) {
    solve(n,q);
  }
  
}
