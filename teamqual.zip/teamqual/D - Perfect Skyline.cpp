#include <bits/stdc++.h>

using namespace std;
using ll = long long;

int main() {
  int n, m;
  cin >> n >> m;
 int N = 1 << n;
  vector<int> A(n), B(m);
  for (int i=0;i<n;i++) {
    cin >> A[i];
  }
  map<int, vector<int>> M;
  for (int i=0;i<m;i++) {
    cin >> B[i];
    M[B[i]] = {};
  }
  
  for (int msk=0;msk<N;msk++) {
    ll sum = 0;
    for (int i=0;i<n;i++) {
      if ((msk >> i) & 1) {
        sum += A[i];
      }
    }
    if (sum <= (int)1e9) {
      if (M.count(sum)) {
        M[sum].push_back(msk);
      }
    }
  }

  vector<vector<int>> dp(m+1, vector<int>(N));
  vector<vector<int>> prev(m+1, vector<int>(N));
  dp[0][0] = true;
  for (int i=0;i<m;i++) {
    for (int msk = 0; msk < N; msk++) {
      if (!dp[i][msk]) continue;
      for (int nxt : M[B[i]]) {
        if ((nxt & msk) == 0 && !dp[i+1][nxt | msk]) {
          dp[i+1][nxt | msk] = true;
          prev[i+1][nxt | msk] = msk;
        }
      }
    }
  }
  for (int i=0;i<N;i++) {
    if (dp[m][i]) {
      vector<vector<int>> ans(m);
      int cur = i;
      int j = m;

      while (cur != 0) {
        int delta = cur ^ prev[j][cur];
        for (int k=0;k<n;k++){
          if ((delta >> k) & 1) {
            ans[j-1].push_back(k);
          }
        }
        cur = prev[j][cur];
        j--;
      }
      for (auto& arr : ans) {
        cout << arr.size() << " ";
        for (int a : arr) {
          cout << a + 1 << " ";
        }
        cout << "\n";
      }
      return 0;
    }
  }
  cout << -1 << "\n";
}
