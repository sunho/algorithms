#include <bits/stdc++.h>

using namespace std;
using ll = long long;

int main() {
  int n,k;
  cin >> n >> k;
  vector<int> vals;
  vector<pair<int,int>> A;
  for (int i=0;i<n;i++) {
    int s,t;
    cin >> s >> t;
    vals.push_back(s);
    vals.push_back(t);
    A.push_back({s,t});
  }
  sort(begin(A),end(A));
  multiset<int> cur;
  int ans = 0;
  for (int i=0;i<n;i++) {
    auto [l,r] = A[i];
    while (!cur.empty() && *cur.begin() < l) {
      cur.erase(cur.begin());
    }
    if (cur.size() < k) {
      cur.insert(r);
      ans++;
    } else { 
      if (cur.upper_bound(r) != cur.end()) {
        cur.insert(r);
        cur.erase(--cur.end());
      }
    }
  }
  cout << ans << "\n";
}
