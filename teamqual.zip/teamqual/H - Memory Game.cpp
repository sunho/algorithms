#include <bits/stdc++.h>

using namespace std;

using ld = long double;

const int N = 1e3;

ld dp[N+1][N+1];
bool done[N+1][N+1];

ld solve(int x,int y) {
  if (x == y) {
    return y;
  }
  if (x == 0) {
    return 0;
  }
  if (done[x][y]) {
    return dp[x][y];
  }
  ld res = 0.0l;
  ld cc = 0.0;
  if (y >= 1) {
    res += (ld)y/(2*x-y) * (solve(x-1,y-1) + 1);
  }
  res += (1.0l-(ld)y/(2*x-y)) * ((ld)y / (2*x-y-1))*(solve(x-1,y) + 2);
  cc += ((ld)y) / (2*x-y-1);
  res += (1.0l-(ld)y/(2*x-y)) * (1.0l / (2*x-y-1))*(solve(x-1,y) + 1);
  cc += 1.0l / (2*x-y-1);
  if (y + 2 <= x) {
    res += (1.0l-(ld)y/(2*x-y)) * (1.0l - cc)*(solve(x, y+2) + 1);
  }
  done[x][y] = true;
  dp[x][y] = res;
  return res;
}

int main() {
  int n;
  cin >> n;
  cout << setprecision(14) << fixed << solve(n, 0) << "\n";
}
