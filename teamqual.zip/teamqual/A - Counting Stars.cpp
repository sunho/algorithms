#include <bits/stdc++.h>

using namespace std;

int T = 0;

void solve(int n, int m) {
  vector<vector<char>> M(n, vector<char>(m));
  for (int i=0;i<n;i++) {
    for (int j=0;j<m;j++) {
      cin >> M[i][j];
    }
  }

  vector<vector<bool>> vis(n, vector<bool>(m));
  auto dfs = [&](auto&& self, int i, int j) {
    if (vis[i][j]) {
      return;
    }
    vis[i][j] = true;
    vector<pair<int,int>> cands = {{i+1,j},{i-1,j},{i,j+1},{i,j-1}};
    for (auto [x,y] : cands) {
      if (x < 0 || x >= n || y < 0 || y >= m) {
        continue;
      }
      if (M[x][y] == '#') {
        continue;
      }
      self(self, x, y);
    }
  };
  
  int ans = 0;
  for (int i=0;i<n;i++) {
    for (int j=0;j<m;j++) {
      if (M[i][j] != '#' && !vis[i][j]) {
        ans++;
        dfs(dfs, i, j);
      }
    }
  }
  cout << "Case " << T + 1 << ": " << ans << "\n";
  T++;
}

int main() {
  int n,m;
  while (cin >> n >> m) {
    solve(n,m);
  }
}
