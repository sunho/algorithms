#include <bits/stdc++.h>

using namespace std;
using ll = long long;

struct fenwick_tree {
  int n;
  vector<ll> bits;
  fenwick_tree(int n) : n(n), bits(n+1) {}
  void update(int v, int delta) { 
    for (++v; v <= n; v += v&(-v)) {
      bits[v] += delta;
    }
  } 
  ll query(int r) {
    ll res =0;
    for (++r; r > 0; r -= r&(-r)) {
      res += bits[r];
    }
    return res;
  }
  ll query(int l, int r) { return query(r) - query(l-1); }
};

int main() {
  int n;
  cin >> n;
  vector<int> A(n);
  vector<int> vals;
  for (int i=0;i<n;i++) {
    cin >> A[i];
    vals.push_back(A[i]);
  }
  sort(begin(vals),end(vals));
  vector<int> inv(n);
  for (int i=0;i<n;i++) {
    A[i] = lower_bound(begin(vals),end(vals),A[i]) - begin(vals);
    inv[A[i]] = i;
  }
  fenwick_tree ft(n);
  ll ans = 0;
  for (int i=0;i<n;i++) {
    int j = inv[i];
    ans += ft.query(j,n-1);
    ft.update(j, 1);
  }
  cout << ans << "\n";
}
